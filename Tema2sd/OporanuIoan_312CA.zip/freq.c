// Copyright 2020 <Oporanu Ioan Nicolae>
#include<stdio.h>
#include<stdlib.h>
int main() {
  unsigned char *v;
  int a;
  v = calloc(2000000, sizeof(int));
  while (!feof(stdin)) {
    scanf("%d", &a);
    scanf("\n");
    v[a]++;
  }
  for (int i = 0; i <= 2000000; i++) {
    if (v[i] != 0) {
      printf("%d %d\n", i, v[i]);
    }
  }
  free(v);
  return 0;
}
